
using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class DialogPlugin
{
#if UNITY_EDITOR_WIN

	public delegate void UnitySendMessageDelegate( [MarshalAs( UnmanagedType.LPWStr )]string gameObjectName, [MarshalAs( UnmanagedType.LPWStr )]string methodName, [MarshalAs( UnmanagedType.LPWStr )]string message );

	/// <summary>
	/// Win32のMessageBoxを表示する
	/// </summary>
	/// <param name="message">メッセージ</param>
	/// <param name="title">タイトル</param>
	/// <param name="type">種類</param>
	/// <param name="unitySendMessage"></param>
	[DllImport( "MessageBoxPlugin" )]
	private static extern void
	MessageBoxPlugin(
	    [MarshalAs( UnmanagedType.LPWStr )]string message,
	    [MarshalAs( UnmanagedType.LPWStr )]string title,
	    uint type,
	    UnitySendMessageDelegate unitySendMessage );

	/// <summary>
	/// UnitySendMessageをまねるもの
	/// </summary>
	/// <param name="gameObjectName"></param>
	/// <param name="methodName"></param>
	/// <param name="message"></param>
	private static void UnitySendMessage( string gameObjectName, string methodName, string message )
	{
		var gameObject = GameObject.Find( gameObjectName );

		if( gameObject != null )
		{
			gameObject.SendMessage( methodName, message );
		}
	}

#endif

#if UNITY_EDITOR_OSX

	private delegate void UnitySendMessageDelegate(string gameObjectName, string methodName, string message);

	[DllImport( "AlertDialog" )]
	private static extern void showAlertDialog3Button( string title, string message, string yes, string no, string cancel, UnitySendMessageDelegate unitySendMessage );

	[DllImport( "AlertDialog" )]
	private static extern void showAlertDialog2Button( string title, string message, string ok, string cancel, UnitySendMessageDelegate unitySendMessage );

	[DllImport( "AlertDialog" )]
	private static extern void showAlertDialog1Button( string title, string message, string ok, UnitySendMessageDelegate unitySendMessage );

	/// <summary>
	/// UnitySendMessageをまねるもの
	/// </summary>
	/// <param name="gameObjectName"></param>
	/// <param name="methodName"></param>
	/// <param name="message"></param>
	[AOT.MonoPInvokeCallback(typeof(UnitySendMessageDelegate))]
	private static void UnitySendMessage( string gameObjectName, string methodName, string message )
	{
		var gameObject = GameObject.Find( gameObjectName );

		if( gameObject != null )
		{
			gameObject.SendMessage( methodName, message );
		}
	}

#endif

#if UNITY_IOS
	[DllImport( "__Internal" )]
	private static extern void showAlertDialog3Button( string title, string message, string yes, string no, string cancel );

	[DllImport( "__Internal" )]
	private static extern void showAlertDialog2Button( string title, string message, string ok, string cancel );

	[DllImport( "__Internal" )]
	private static extern void showAlertDialog1Button( string title, string message, string ok );

	[DllImport( "__Internal" )]
	private static extern void hideCurrentAlert();

#endif

	/// <summary>
	/// ダイアログを表示する
	/// </summary>
	/// <param name="title">タイトル</param>
	/// <param name="message">メッセージ</param>
	/// <param name="yes">Yesの文字列</param>
	/// <param name="no">Noの文字列</param>
	/// <param name="cancel">Cancelの文字列</param>
	public static void ShowDialog3Button( string title, string message, string yes, string no, string cancel )
	{
#if UNITY_EDITOR_WIN

		// Yes,No,Cancelの文字列を変えることはできない
		const uint MB_YESNOCANCEL = 0x00000003;
		MessageBoxPlugin( message, title, MB_YESNOCANCEL, UnitySendMessage );

#elif UNITY_EDITOR_OSX

		showAlertDialog3Button( title, message, yes, no, cancel, UnitySendMessage );

#elif UNITY_IOS

		showAlertDialog3Button( title, message, yes, no, cancel );

#elif UNITY_ANDROID

		using( AndroidJavaClass javaUnityClass = new AndroidJavaClass( "angoo.red.nativedialog.NativeDialogPlugin" ) )
		{
			javaUnityClass.CallStatic( "showAlertDialog3Button", title, message, yes, no, cancel );
		}

#endif
	}

	/// <summary>
	/// ダイアログを表示する
	/// </summary>
	/// <param name="title">タイトル</param>
	/// <param name="message">メッセージ</param>
	/// <param name="ok">OKの文字列</param>
	/// <param name="cancel">Cancelの文字列</param>
	public static void ShowDialog2Button( string title, string message, string ok, string cancel )
	{
#if UNITY_EDITOR_WIN

		// Ok,Cancelの文字列を変えることはできない
		const uint MB_OKCANCEL = 0x00000001;
		MessageBoxPlugin( message, title, MB_OKCANCEL, UnitySendMessage );

#elif UNITY_EDITOR_OSX

		showAlertDialog2Button( title, message, ok, cancel, UnitySendMessage );

#elif UNITY_IOS

		showAlertDialog2Button( title, message, ok, cancel );

#elif UNITY_ANDROID

		using( AndroidJavaClass javaUnityClass = new AndroidJavaClass( "angoo.red.nativedialog.NativeDialogPlugin" ) )
		{
			javaUnityClass.CallStatic( "showAlertDialog2Button", title, message, ok, cancel );
		}

#endif
	}

	/// <summary>
	/// ダイアログを表示する
	/// </summary>
	/// <param name="title">タイトル</param>
	/// <param name="message">メッセージ</param>
	/// <param name="ok">OKの文字列</param>
	public static void ShowDialog1Button( string title, string message, string ok )
	{
#if UNITY_EDITOR_WIN

		// Okの文字列を変えることはできない
		const uint MB_OK = 0x00000000;
		MessageBoxPlugin( message, title, MB_OK, UnitySendMessage );

#elif UNITY_EDITOR_OSX

		showAlertDialog1Button( title, message, ok, UnitySendMessage );

#elif UNITY_IOS

		showAlertDialog1Button( title, message, ok );

#elif UNITY_ANDROID

		using( AndroidJavaClass javaUnityClass = new AndroidJavaClass( "angoo.red.nativedialog.NativeDialogPlugin" ) )
		{
			javaUnityClass.CallStatic( "showAlertDialog1Button", title, message, ok );
		}

#endif
	}

	public static void HideCurrentAlert()
	{
#if UNITY_WINDOWS
#elif UNITY_EDITOR_OSX
#elif UNITY_IOS
		hideCurrentAlert();
#elif UNITY_ANDROID

		using( AndroidJavaClass javaUnityClass = new AndroidJavaClass( "angoo.red.nativedialog.NativeDialogPlugin" ) )
		{
			javaUnityClass.CallStatic( "hideCurrentAlert" );
		}

#endif
	}

}
